import logo from './logo.svg';
import './App.css';
import icon from './images/olx-icon.PNG'
import mainimg from './images/image1.jpg'
import prduct from './images/image 2.png'
import olxappimg from './images/olx app image.png'
import icons from './images/icons.png'
import appimage from './images/appimage.png'

function Header() {
  return (
    <div className="header">
      <nav className="navbar sticky-top navbar-expand-lg navbar-light bg-light">
        <a className="navbar-brand" href="#"><img src={icon} alt="" /></a>
        <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
          <span className="navbar-toggler-icon" />
        </button>

        <div className="collapse navbar-collapse" id="navbarNavDropdown">
          <ul className="navbar-nav">
            <li className="nav-item active">
              <input className="search-city" placeholder="Search city,area or local" />
            </li>
            <li className="nav-item">
              <input className="search" placeholder="Find car mobile phones and more..." />
            </li>
            <li className="nav-item item">
              <a className="login" href="#">Login</a>
            </li>
            <li className="nav-item sellbtnn">
              <button class="sellbtn"> + SELL </button>
            </li>
          </ul>
        </div>
      </nav>
      <div>
        <ul className="links">
          <li className="linkb"><b>ALL CATEGORIES </b> </li>
          <li className="link">Mobile Phones</li>
          <li className="link">Cars</li>
          <li className="link">Motorcycles</li>
          <li className="link">Houses</li>
          <li className="link">TV-Video</li>
          <li className="link">Tablets</li>
          <li className="link">Land & Plots</li>
        </ul>
      </div>
    </div>
  );
}


function Body() {
  return (
    <div>
      <img src={mainimg} />

      <div className="maindiv">
        <div className="resentserch--div">
          <h4>Based on your last search</h4>
          <a className="a" href="#">view more</a>
        </div>
        <div className="resentbox">



          <div className="card">
            <img src={prduct} /><br />
            <div className="inerdiv1">
              <h5>Rs 39,999</h5>
              <p className="carddescribe">Infinix Zero 8 128gb Built</p>
              <p className="carddate">karachi,<span id="cardespan"> 20-12-2020</span></p>
            </div>
          </div>
          <div className="card">
            <img src={prduct} /><br />
            <div className="inerdiv1">
               <h5>Rs 39,999</h5>
              <p className="carddescribe">Infinix Zero 8 128gb Built</p>
              <p className="carddate">karachi,<span id="cardespan"> 20-12-2020</span></p>
            </div>
          </div>
          <div className="card">
            <img src={prduct} /><br />
            <div className="inerdiv1">
               <h5>Rs 39,999</h5>
              <p className="carddescribe">Infinix Zero 8 128gb Built</p>
              <p className="carddate">karachi,<span id="cardespan"> 20-12-2020</span></p>
            </div>
          </div>
          <div className="card">
            <img src={prduct} /><br />
            <div className="inerdiv1">
               <h5>Rs 39,999</h5>
              <p className="carddescribe">Infinix Zero 8 128gb Built</p>
              <p className="carddate">karachi,<span id="cardespan"> 20-12-2020</span></p>
            </div>
          </div>
        </div>
      </div>



      <div className="recommendations">Fresh recommendations</div>
      <div className="bodydiv">

      <div className="card">
        <img src={prduct} /><br/>
        <div   className="inerdiv1">
           <h5>Rs 39,999</h5>
          <p className="carddescribe">Infinix Zero 8 128gb Built</p>
          <p className="carddate">karachi,<span id="cardespan"> 20-12-2020</span></p>
        </div>
        </div>
 
        <div className="card">
        <img src={prduct} /><br/>
        <div   className="inerdiv1">
           <h5>Rs 39,999</h5>
          <p className="carddescribe">Infinix Zero 8 128gb Built</p>
          <p className="carddate">karachi,<span id="cardespan"> 20-12-2020</span></p>
        </div>
        </div>
        <div className="card">
           <img src={prduct} /><br/>
          <div className="inerdiv1">
             <h5>Rs 39,999</h5>
            <p className="carddescribe">Infinix Zero 8 128gb Built</p>
            <p className="carddate">karachi,<span id="cardespan"> 20-12-2020</span></p>
          </div>
        </div>
        <div className="card">
           <img src={prduct} /><br/>
          <div className="inerdiv1">
             <h5>Rs 39,999</h5>
            <p className="carddescribe">Infinix Zero 8 128gb Built</p>
            <p className="carddate">karachi,<span id="cardespan"> 20-12-2020</span></p>
          </div>
        </div>
        <div className="card">
           <img src={prduct} /><br/>
          <div className="inerdiv1">
             <h5>Rs 39,999</h5>
            <p className="carddescribe">Infinix Zero 8 128gb Built</p>
            <p className="carddate">karachi,<span id="cardespan"> 20-12-2020</span></p>
          </div>
        </div>
        <div className="card">
           <img src={prduct} /><br/>
          <div className="inerdiv1">
             <h5>Rs 39,999</h5>
            <p className="carddescribe">Infinix Zero 8 128gb Built</p>
            <p className="carddate">karachi,<span id="cardespan"> 20-12-2020</span></p>
          </div>
        </div>
        <div className="card">
           <img src={prduct} /><br/>
          <div className="inerdiv1">
             <h5>Rs 39,999</h5>
            <p className="carddescribe">Infinix Zero 8 128gb Built</p>
            <p className="carddate">karachi,<span id="cardespan"> 20-12-2020</span></p>
          </div>
        </div>
        <div className="card">
           <img src={prduct} /><br/>
          <div className="inerdiv1">
             <h5>Rs 39,999</h5>
            <p className="carddescribe">Infinix Zero 8 128gb Built</p>
            <p className="carddate">karachi,<span id="cardespan"> 20-12-2020</span></p>
          </div>
        </div>
        <div className="card">
           <img src={prduct} /><br/>
          <div className="inerdiv1">
             <h5>Rs 39,999</h5>
            <p className="carddescribe">Infinix Zero 8 128gb Built</p>
            <p className="carddate">karachi,<span id="cardespan"> 20-12-2020</span></p>
          </div>
        </div>
        <div className="card">
           <img src={prduct} /><br/>
          <div className="inerdiv1">
             <h5>Rs 39,999</h5>
            <p className="carddescribe">Infinix Zero 8 128gb Built</p>
            <p className="carddate">karachi,<span id="cardespan"> 20-12-2020</span></p>
          </div>
        </div>
        <div className="card">
           <img src={prduct} /><br/>
          <div className="inerdiv1">
             <h5>Rs 39,999</h5>
            <p className="carddescribe">Infinix Zero 8 128gb Built</p>
            <p className="carddate">karachi,<span id="cardespan"> 20-12-2020</span></p>
          </div>
        </div>
        <div className="card">
           <img src={prduct} /><br/>
          <div className="inerdiv1">
             <h5>Rs 39,999</h5>
            <p className="carddescribe">Infinix Zero 8 128gb Built</p>
            <p className="carddate">karachi,<span id="cardespan"> 20-12-2020</span></p>
          </div>
        </div>
        <div className="card">
           <img src={prduct} /><br/>
          <div className="inerdiv1">
             <h5>Rs 39,999</h5>
            <p className="carddescribe">Infinix Zero 8 128gb Built</p>
            <p className="carddate">karachi,<span id="cardespan"> 20-12-2020</span></p>
          </div>
        </div>
        <div className="card">
           <img src={prduct} /><br/>
          <div className="inerdiv1">
             <h5>Rs 39,999</h5>
            <p className="carddescribe">Infinix Zero 8 128gb Built</p>
            <p className="carddate">karachi,<span id="cardespan"> 20-12-2020</span></p>
          </div>
        </div>
        <div className="card">
           <img src={prduct} /><br/>
          <div className="inerdiv1">
             <h5>Rs 39,999</h5>
            <p className="carddescribe">Infinix Zero 8 128gb Built</p>
            <p className="carddate">karachi,<span id="cardespan"> 20-12-2020</span></p>
          </div>
        </div>
        <div className="card">
           <img src={prduct} /><br/>
          <div className="inerdiv1">
             <h5>Rs 39,999</h5>
            <p className="carddescribe">Infinix Zero 8 128gb Built</p>
            <p className="carddate">karachi,<span id="cardespan"> 20-12-2020</span></p>
          </div>
        </div>
      </div>
      <div className="morebtndiv">
        <button className="loadmore">load more</button>
      </div>
      <div className="olxapp">
        <img width="100%" src="image/olx app image.png" alt="" />
      </div>
    </div>
  );
}
function Footer() {
  return (
    <div>
       <img width="100%" src={olxappimg} alt="" />
    <div className="footer">
      <div>
        <ul>
          <li className="footerlibold"><b>POPULAR CATEGORIES</b></li>
          <li className="footerli">Cars</li>
          <li className="footerli">Flats for rent</li>
          <li className="footerli">Jobs</li>
          <li className="footerli">Mobile Phones</li>
        </ul>
      </div>
      <div>
        <ul>
          <li className="footerlibold"><b>TRENDING SEARCHES</b></li>
          <li className="footerli">Bikes</li>
          <li className="footerli">Watches</li>
          <li className="footerli">Books</li>
          <li className="footerli">Dogs</li>
        </ul>
      </div>
      <div>
        <ul>
          <li className="footerlibold"><b>ABOUT US</b></li>
          <li className="footerli">About OLX Group</li>
          <li className="footerli">OLX Blog</li>
          <li className="footerli">Contact Us</li>
          <li className="footerli">OLX for Businesses</li>
        </ul>
      </div>
      <div>
        <ul>
          <li className="footerlibold"><b>OLX</b></li>
          <li className="footerli">Help</li>
          <li className="footerli">Sitemap</li>
          <li className="footerli">Legal &amp; Privacy information</li>
        </ul>
      </div>
      <div>
        <b className="footerlibold">FOLLOW US</b><br />
        <img className="fottericon" src={icons} alt="" /><br />
        <img className="footerappicon" src={appimage} alt="" />
      </div>
    </div>
    <div className="footer2">
      <p className="footertext"><b>Other Countries India - South Africa - Indonesia</b></p>
      <p className="footertext2">Free Classifieds in Pakistan. © 2006-2020 OLX</p>
    </div>
  </div>
  );
}


function App() {
  return (
    <div className="mainbody-div">
      <Header />
      <Body />
      <Footer/>


    </div>
  );
}

export default App;
